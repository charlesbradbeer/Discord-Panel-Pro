<?php

/* General Settings */
$brandname = 'Jupiters Bot Panel'; // Panel Name
$websiterememberme = 'true'; // Website remember me option... true = On. false = off
$clientID = '448926424439586817'; // Put your Discord Client ID for logging in.
$clientSecret = 'ezAXFs3rX23FKzy6rZIFwnVL2NcrvckK'; // Put your Discord Client Secret for logging in.
$redirectURI = 'https://jupiterr.club/callback/login.php'; // Put your Discord Redirect URI for logging in. (Should be https://url.tld/callback/login.php)

/* Bot 1 */
$bot1 = 'Goku'; // Name of the first Bot
$Bot1about = 'Goku - A good bot ok'; // About details for the first bot
$Bot1smalldetail = 'Main bot'; // Small details about first bot
$bot1image = 'https://cdn.discordapp.com/attachments/413058251496751107/448926857409069066/oof.jpg'; // Bot image for first bot
$bot1ID = '282088833082720256'; // Bot ID for first bot - used to get status from DiscordBots.org
$bot1IP = ''; // The IP of the server that the first bot is hosted on
$bot1User = ''; // The user that the first bot is hosted on (Root if possible)
$bot1Password = ''; // The users password to login to the first bots server
$bot1location = ''; // The location the bot files are at (Doesn't need the first "/"

/* Bot 2 */
$bot2 = 'Bot2'; // Name of the second Bot
$Bot2about = 'Write what you want!';// About details for the second bot
$Bot2smalldetail = 'Demo bot'; // Small details about second bot
$bot2image = ''; // Bot image for second bot
$bot2ID = '277234960807755776'; // Bot ID for second bot - used to get status from DiscordBots.org
$bot2IP = ''; // The IP of the server that the second bot is hosted on
$bot2User = ''; // The user that the second bot is hosted on (Root if possible)
$bot2Password = ''; // The users password to login to the second bots server
$bot2location = ''; // The location the bot files are at (Doesn't need the second "/"

/* Bot 3 */
$bot3 = 'Bot3'; // Name of the third Bot
$Bot3about = 'Write what you want!';// About details for the third bot
$Bot3smalldetail = 'Beta bot'; // Small details about thrid bot
$bot3image = ''; // Bot image for third bot
$bot3ID = '218921854662868993'; // Bot ID for third bot - used to get status from DiscordBots.org
$bot3IP = ''; // The IP of the server that the third bot is hosted on
$bot3User = ''; // The user that the third bot is hosted on (Root if possible)
$bot3Password = ''; // The users password to login to the third bots server
$bot3location = ''; // The location the bot files are at (Doesn't need the third "/"

/* Bot 4 */
$bot4 = 'Bot4'; // Name of the fourth Bot
$Bot4about = 'Write what you want!';// About details for the fourth bot
$Bot4smalldetail = 'Cheese bot'; // Small details about fourth bot
$bot4image = ''; // Bot image for fourth bot
$bot4ID = '307998818547531777'; // Bot ID for fourth bot - used to get status from DiscordBots.org
$bot4IP = ''; // The IP of the server that the fourth bot is hosted on
$bot4User = ''; // The user that the fourth bot is hosted on (Root if possible)
$bot4Password = ''; // The users password to login to the fourth bots server
$bot4location = ''; // The location the bot files are at (Doesn't need the fourth "/"

/* TOS */
$terms = 'You would replace this for terms of reporting a bug'; // The popup area when someone clicks to view the the terms of reporting a bug


/* Database things */

$server = 'localhost'; // Database server IP (Can be localhost)
$username = 'mcserver_gokuadmin'; // Database username
$password = 'Y{g;OMtEunAM'; // Database User Password
$db = 'mcserver_goku'; // Database name
?>