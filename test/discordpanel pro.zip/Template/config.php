<?php

/* General Settings */
$brandname = 'DiscordPanel Pro'; // Panel Name
$adminemail = 'mail@discordpanel.xyz'; // Panel Email
$panelurl = 'https://pro.discordpanel.xyz/'; // Panel URL with "/"
$websiterememberme = 'true'; // Website remember me option... true = On. false = off
$clientID = '483288480206684170'; // Put your Discord Client ID for logging in.
$clientSecret = 'FlkLCTzmDyhNuiEOdGDZYdfrg4oVubr3'; // Put your Discord Client Secret for logging in.
$redirectURI = 'https://pro.discordpanel.xyz/callback/login.php'; // Put your Discord Redirect URI for logging in. (Should be https://url.tld/callback/login.php)

/* Bot 1 */
$bot1 = 'Bot1'; // Name of the first Bot
$Bot1about = 'Write what you want!'; // About details for the first bot
$Bot1smalldetail = 'Main bot'; // Small details about first bot
$bot1image = 'https://cdn.discordapp.com/avatars/297402871240982529/fa45c231bb65a5f920f103c393a8c737.png'; // Bot image for first bot (Hosted online)
$bot1ID = '356065937318871041'; // Bot ID for first bot
$bot1IP = '204.44.75.176'; // The IP of the server that the first bot is hosted on
$bot1User = 'root'; // The user that the first bot is hosted on (Root if possible)
$bot1location = 'cmbbot'; // The location the bot files are at (Doesn't need the first "/"

/* Bot 2 */
$bot2 = 'Bot2'; // Name of the second Bot
$Bot2about = 'Write what you want!';// About details for the second bot
$Bot2smalldetail = 'Demo bot'; // Small details about second bot
$bot2image = 'https://cdn.discordapp.com/avatars/297402871240982529/fa45c231bb65a5f920f103c393a8c737.png'; // Bot image for second bot (Hosted online)
$bot2ID = '277234960807755776'; // Bot ID for second bot
$bot2IP = '204.44.75.176'; // The IP of the server that the second bot is hosted on
$bot2User = 'root'; // The user that the second bot is hosted on (Root if possible)
$bot2location = ''; // The location the bot files are at (Doesn't need the second "/"

/* Bot 3 */
$bot3 = 'Bot3'; // Name of the third Bot
$Bot3about = 'Write what you want!';// About details for the third bot
$Bot3smalldetail = 'Beta bot'; // Small details about thrid bot
$bot3image = 'https://cdn.discordapp.com/avatars/297402871240982529/fa45c231bb65a5f920f103c393a8c737.png'; // Bot image for third bot (Hosted online)
$bot3ID = '218921854662868993'; // Bot ID for third bot
$bot3IP = '204.44.75.176'; // The IP of the server that the third bot is hosted on
$bot3User = 'root'; // The user that the third bot is hosted on (Root if possible)
$bot3location = ''; // The location the bot files are at (Doesn't need the third "/"

/* Bot 4 */
$bot4 = 'Bot4'; // Name of the fourth Bot
$Bot4about = 'Write what you want!';// About details for the fourth bot
$Bot4smalldetail = 'Cheese bot'; // Small details about fourth bot
$bot4image = 'https://cdn.discordapp.com/avatars/297402871240982529/fa45c231bb65a5f920f103c393a8c737.png'; // Bot image for fourth bot (Hosted online)
$bot4ID = '307998818547531777'; // Bot ID for fourth bot
$bot4IP = '204.44.75.176'; // The IP of the server that the fourth bot is hosted on
$bot4User = 'root'; // The user that the fourth bot is hosted on (Root if possible)
$bot4location = ''; // The location the bot files are at (Doesn't need the fourth "/"

/* Bot 5 */
$bot5 = 'Bot5'; // Name of the fifth Bot
$Bot5about = 'Write what you want!';// About details for the fifth bot
$Bot5smalldetail = 'Beta bot'; // Small details about thrid bot
$bot5image = 'https://cdn.discordapp.com/avatars/297402871240982529/fa45c231bb65a5f920f103c393a8c737.png'; // Bot image for fifth bot (Hosted online)
$bot5ID = '218921854662868993'; // Bot ID for fifth bot
$bot5IP = '204.44.75.176'; // The IP of the server that the fifth bot is hosted on
$bot5User = 'root'; // The user that the fifth bot is hosted on (Root if possible)
$bot5location = ''; // The location the bot files are at (Doesn't need the fifth "/"

/* Bot 6 */
$bot6 = 'Bot6'; // Name of the sixth Bot
$Bot6about = 'Write what you want!';// About details for the sixth bot
$Bot6smalldetail = 'Cheese bot'; // Small details about sixth bot
$bot6image = 'https://cdn.discordapp.com/avatars/297402871240982529/fa45c231bb65a5f920f103c393a8c737.png'; // Bot image for sixth bot (Hosted online)
$bot6ID = '307998818547531777'; // Bot ID for sixth bot
$bot6IP = '204.44.75.176'; // The IP of the server that the sixth bot is hosted on
$bot6User = 'root'; // The user that the sixth bot is hosted on (Root if possible)
$bot6location = ''; // The location the bot files are at (Doesn't need the sixth "/"

/* TOS */
$terms = 'You would replace this for terms of reporting a bug'; // The popup area when someone clicks to view the the terms of reporting a bug


/* Database things */

$server = 'localhost'; // Database server IP (Can be localhost)
$username = 'musiciny_discordpanel'; // Database username
$password = 'qgKCD}C0kx$Z'; // Database User Password
$db = 'musiciny_discordpanel'; // Database name
?>