<?php
include('config.php');
?>
<center><p><b>Bot ID:</b><?php echo $bot1ID; ?></p>
<p><b>Bot Status:</b>
<img src="https://discordbots.org/api/widget/status/<?php echo $bot1ID; ?>.svg" alt="Bot Status">
<p><b>Logo:</b></p><img src="<?php echo $bot1image; ?>" width="60" height="60">
</center>